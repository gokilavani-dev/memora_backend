import "dotenv/config";
import { searchNotes } from "./services/similarity.service";

async function main() {
  const results = await searchNotes(
    "test-note-001",
    "What is Newton's law about?",
    2,
  );

  for (const result of results) {
    console.log("---");
    console.log("chunkId:", result.chunkId);
    console.log("score:", result.score);
    console.log("text:", result.text);
  }
}

main();
